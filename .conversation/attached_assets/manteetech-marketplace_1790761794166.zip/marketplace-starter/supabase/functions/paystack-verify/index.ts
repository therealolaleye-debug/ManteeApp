// Deploy with:
// supabase functions deploy paystack-verify
//
// Set PAYSTACK_SECRET_KEY as a Supabase project secret.
// This function verifies a Paystack reference before the app marks an order paid.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};

serve(async (request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { reference, orderId } = await request.json();
    if (!reference || !orderId) throw new Error("reference and orderId are required");

    const verifyResponse = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${Deno.env.get("PAYSTACK_SECRET_KEY")}` }
    });
    const verification = await verifyResponse.json();
    if (!verifyResponse.ok || verification.data?.status !== "success") {
      throw new Error("Payment could not be verified");
    }

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );
    const { error } = await admin.from("orders").update({
      status: "paid",
      paystack_reference: reference,
      updated_at: new Date().toISOString()
    }).eq("id", orderId);
    if (error) throw error;

    return new Response(JSON.stringify({ ok: true, reference }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
});