-- MANTEETECH MARKETPLACE / SUPABASE SCHEMA
-- Run this file in Supabase SQL Editor, then apply seed.sql for the demo catalog.
create extension if not exists "pgcrypto";

create type public.user_role as enum ('customer', 'admin');
create type public.order_status as enum ('pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role public.user_role not null default 'customer',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  category text not null,
  price integer not null check (price >= 0),
  compare_at integer check (compare_at is null or compare_at >= price),
  image_url text not null,
  colors text[] not null default '{}',
  stock integer not null default 0 check (stock >= 0),
  badge text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  email text not null,
  shipping_address text not null,
  status public.order_status not null default 'pending',
  total integer not null check (total >= 0),
  paystack_reference text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price integer not null check (unit_price >= 0),
  created_at timestamptz not null default now()
);

create table public.wishlists (
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.wishlists enable row level security;

create policy "Public can read active products" on public.products for select using (is_active = true or (select role from public.profiles where id = auth.uid()) = 'admin');
create policy "Customers read their orders" on public.orders for select using (user_id = auth.uid() or (select role from public.profiles where id = auth.uid()) = 'admin');
create policy "Customers read their order items" on public.order_items for select using (exists (select 1 from public.orders where orders.id = order_items.order_id and (orders.user_id = auth.uid() or (select role from public.profiles where id = auth.uid()) = 'admin')));
create policy "Users read own profile" on public.profiles for select using (id = auth.uid());
create policy "Users update own profile" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "Users manage own wishlist" on public.wishlists for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "Admins manage products" on public.products for all using ((select role from public.profiles where id = auth.uid()) = 'admin') with check ((select role from public.profiles where id = auth.uid()) = 'admin');

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.create_order(p_items jsonb, p_email text, p_shipping_address text)
returns public.orders language plpgsql security definer set search_path = public as $$
declare item jsonb; new_order public.orders; calculated_total integer := 0; product_row public.products;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  for item in select * from jsonb_array_elements(p_items) loop
    select * into product_row from public.products where id = (item->>'product_id')::uuid and is_active = true for update;
    if product_row.id is null then raise exception 'Product not found'; end if;
    if product_row.stock < (item->>'quantity')::integer then raise exception 'Insufficient stock for %', product_row.name; end if;
    calculated_total := calculated_total + (product_row.price * (item->>'quantity')::integer);
  end loop;
  insert into public.orders (user_id, email, shipping_address, total) values (auth.uid(), p_email, p_shipping_address, calculated_total) returning * into new_order;
  for item in select * from jsonb_array_elements(p_items) loop
    select * into product_row from public.products where id = (item->>'product_id')::uuid;
    insert into public.order_items (order_id, product_id, product_name, quantity, unit_price) values (new_order.id, product_row.id, product_row.name, (item->>'quantity')::integer, product_row.price);
    update public.products set stock = stock - (item->>'quantity')::integer where id = product_row.id;
  end loop;
  return new_order;
end;
$$;
revoke all on function public.create_order(jsonb, text, text) from public;
grant execute on function public.create_order(jsonb, text, text) to authenticated;