import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CONFIG = window.APP_CONFIG || {};
const supabase = CONFIG.supabaseUrl && CONFIG.supabaseAnonKey
  ? createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey)
  : null;

const DEMO_PRODUCTS = [
  { id: "p1", name: "iPhone 15 Pro", category: "Smartphones & Tablets", price: 1450000, compare_at: 1520000, badge: "Bestseller", description: "A powerful flagship phone with a titanium build, pro camera system, and all-day performance.", image_url: "https://images.unsplash.com/photo-1592286927505-2fd0b3e1f30f?auto=format&fit=crop&w=1000&q=85", colors: ["Natural Titanium", "Black Titanium"], stock: 7 },
  { id: "p2", name: "Samsung Galaxy S24", category: "Smartphones & Tablets", price: 980000, compare_at: 1050000, badge: "Featured", description: "A compact Galaxy flagship with a bright display, smart camera tools, and dependable battery life.", image_url: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&w=1000&q=85", colors: ["Onyx Black", "Marble Gray"], stock: 12 },
  { id: "p3", name: "Xiaomi Redmi Note 13", category: "Smartphones & Tablets", price: 285000, compare_at: null, badge: "Value pick", description: "A high-value everyday smartphone with an AMOLED display and generous storage.", image_url: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1000&q=85", colors: ["Midnight Black", "Mint Green"], stock: 20 },
  { id: "p4", name: "Tecno Camon 30", category: "Smartphones & Tablets", price: 315000, compare_at: null, badge: "New in", description: "A camera-first smartphone designed for sharp portraits, social content, and daily multitasking.", image_url: "https://images.unsplash.com/photo-1533228100845-08145b01de14?auto=format&fit=crop&w=1000&q=85", colors: ["Basaltic Dark", "Iceland Basaltic"], stock: 16 },
  { id: "p5", name: "iPad 10th Generation", category: "Smartphones & Tablets", price: 720000, compare_at: 780000, badge: null, description: "A versatile tablet for study, work, streaming, and creative projects.", image_url: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=1000&q=85", colors: ["Blue", "Silver"], stock: 6 },
  { id: "p6", name: "Oraimo PowerBox 20,000mAh", category: "Power & Energy", price: 38500, compare_at: 42000, badge: "Bestseller", description: "High-capacity portable power with dual outputs for busy days, travel, and backup.", image_url: "https://images.unsplash.com/photo-1609592424856-3c0c4f7f6e9b?auto=format&fit=crop&w=1000&q=85", colors: ["Black"], stock: 35 },
  { id: "p7", name: "Anker Nano 30W GaN Charger", category: "Power & Energy", price: 52000, compare_at: null, badge: "Fast charge", description: "A compact GaN charging brick with enough power for phones, tablets, and everyday carry.", image_url: "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=1000&q=85", colors: ["White", "Black"], stock: 22 },
  { id: "p8", name: "Remax 3-in-1 Charging Cable", category: "Power & Energy", price: 12000, compare_at: null, badge: null, description: "One braided cable for Type-C, Lightning, and Micro USB devices.", image_url: "https://images.unsplash.com/photo-1551721434-8b94ddff0e6d?auto=format&fit=crop&w=1000&q=85", colors: ["Black"], stock: 44 },
  { id: "p9", name: "MagSafe Wireless Charging Pad", category: "Power & Energy", price: 29500, compare_at: 34000, badge: "New in", description: "Snap-on wireless charging for compatible phones, with a clean desk-friendly profile.", image_url: "https://images.unsplash.com/photo-1628815113969-048a4d5d4c3b?auto=format&fit=crop&w=1000&q=85", colors: ["White"], stock: 18 },
  { id: "p10", name: "Oraimo FreePods 4", category: "Audio Accessories", price: 36000, compare_at: 41000, badge: "Bestseller", description: "Comfortable TWS earbuds with clear calls, punchy sound, and a pocket-sized case.", image_url: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=1000&q=85", colors: ["Black", "White"], stock: 28 },
  { id: "p11", name: "JBL Go 4 Portable Speaker", category: "Audio Accessories", price: 78000, compare_at: 85000, badge: "Waterproof", description: "A tiny Bluetooth speaker with surprisingly big sound and an easy grab-and-go shape.", image_url: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=1000&q=85", colors: ["Red", "Black"], stock: 10 },
  { id: "p12", name: "Tronsmart T7 Mini Speaker", category: "Audio Accessories", price: 58000, compare_at: null, badge: null, description: "Portable wireless audio with a rugged build for rooms, road trips, and outdoor listening.", image_url: "https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=1000&q=85", colors: ["Black"], stock: 14 },
  { id: "p13", name: "Kieslect Lora 2 Smartwatch", category: "Wearables & Smart Tech", price: 112000, compare_at: 128000, badge: "New in", description: "A polished smartwatch for calls, health insights, notifications, and daily movement.", image_url: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1000&q=85", colors: ["Rose Gold", "Black"], stock: 8 },
  { id: "p14", name: "Bluetooth Smart Tag Tracker", category: "Wearables & Smart Tech", price: 18500, compare_at: null, badge: null, description: "A simple Bluetooth finder for keys, bags, luggage, and the things that disappear at the wrong time.", image_url: "https://images.unsplash.com/photo-1557180295-76eee20ae8aa?auto=format&fit=crop&w=1000&q=85", colors: ["White"], stock: 30 },
  { id: "p15", name: "Rugged Armor Phone Case", category: "Protection & Aesthetics", price: 16500, compare_at: null, badge: null, description: "Shock-absorbing protection with raised edges and a secure grip for everyday drops.", image_url: "https://images.unsplash.com/photo-1601593346740-925612772716?auto=format&fit=crop&w=1000&q=85", colors: ["Smoke", "Black"], stock: 50 },
  { id: "p16", name: "Privacy Tempered Glass", category: "Protection & Aesthetics", price: 9500, compare_at: null, badge: null, description: "Edge-to-edge tempered glass that keeps your screen clear and your viewing private.", image_url: "https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=1000&q=85", colors: ["Clear"], stock: 60 },
  { id: "p17", name: "MagSafe Desktop Grip", category: "Protection & Aesthetics", price: 14500, compare_at: null, badge: "Desk essential", description: "A low-profile magnetic grip and stand for steadier scrolling, calls, and content.", image_url: "https://images.unsplash.com/photo-1556656793-08538906a9f8?auto=format&fit=crop&w=1000&q=85", colors: ["Sage", "Black"], stock: 25 },
  { id: "p18", name: "SanDisk 128GB microSD Card", category: "Storage", price: 18500, compare_at: 22000, badge: "Value pick", description: "Reliable extra storage for phones, tablets, cameras, and portable consoles.", image_url: "https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=1000&q=85", colors: ["Red", "Black"], stock: 33 },
  { id: "p19", name: "Dual-Connector OTG Flash Drive", category: "Storage", price: 22500, compare_at: null, badge: null, description: "Move files between USB-C phones, tablets, laptops, and standard USB ports.", image_url: "https://images.unsplash.com/photo-1623282033815-40b05d96c903?auto=format&fit=crop&w=1000&q=85", colors: ["Silver"], stock: 19 }
];

const state = {
  products: [...DEMO_PRODUCTS],
  cart: JSON.parse(localStorage.getItem("manteetech-cart") || "{}"),
  wishlist: JSON.parse(localStorage.getItem("manteetech-wishlist") || "[]"),
  session: null,
  profile: null,
  activeCategory: "All",
  search: "",
  sort: "featured",
  accountTab: "overview",
  authMode: "signin",
  checkoutStep: 1,
  lastOrder: null
};

const app = document.querySelector("#app");
const modalLayer = document.querySelector("[data-modal-layer]");
const modalContent = document.querySelector("[data-modal-content]");
const cartDrawer = document.querySelector(".cart-drawer");
const drawerBackdrop = document.querySelector("[data-drawer-backdrop]");
const toast = document.querySelector("[data-toast]");
const money = (value) => new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(value);
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[char]));

function saveLocal() {
  localStorage.setItem("manteetech-cart", JSON.stringify(state.cart));
  localStorage.setItem("manteetech-wishlist", JSON.stringify(state.wishlist));
}
function cartEntries() {
  return Object.entries(state.cart).map(([id, quantity]) => ({ product: state.products.find((product) => product.id === id), quantity })).filter((item) => item.product);
}
function cartCount() { return cartEntries().reduce((total, item) => total + item.quantity, 0); }
function cartTotal() { return cartEntries().reduce((total, item) => total + item.product.price * item.quantity, 0); }
function formatDate(date = new Date()) { return new Intl.DateTimeFormat("en-NG", { day: "numeric", month: "short", year: "numeric" }).format(date); }
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timeout);
  showToast.timeout = window.setTimeout(() => toast.classList.remove("show"), 2600);
}
function updateHeader() {
  document.querySelector("[data-cart-count]").textContent = cartCount();
}
function openCart() {
  renderCart();
  cartDrawer.classList.add("open");
  drawerBackdrop.classList.add("open");
  cartDrawer.setAttribute("aria-hidden", "false");
}
function closeCart() {
  cartDrawer.classList.remove("open");
  drawerBackdrop.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden", "true");
}
function openModal(content) {
  modalContent.innerHTML = content;
  modalLayer.hidden = false;
  document.body.style.overflow = "hidden";
}
function closeModal() {
  modalLayer.hidden = true;
  document.body.style.overflow = "";
}
function productCard(product) {
  const wished = state.wishlist.includes(product.id);
  return `<article class="product-card">
    <div class="product-image">
      <img src="${esc(product.image_url)}" alt="${esc(product.name)}" loading="lazy" />
      ${product.badge ? `<span class="product-badge">${esc(product.badge)}</span>` : ""}
      <button class="wish-button ${wished ? "active" : ""}" data-action="wishlist" data-id="${product.id}" aria-label="${wished ? "Remove from wishlist" : "Add to wishlist"}">${wished ? "♥" : "♡"}</button>
    </div>
    <div class="product-info">
      <div class="product-meta">
        <div><h3 class="product-name">${esc(product.name)}</h3><p class="product-category">${esc(product.category)}</p></div>
        <span class="product-price">${money(product.price)}</span>
      </div>
      <div class="product-actions">
        <button class="tiny-button" data-action="quick-view" data-id="${product.id}">Quick view</button>
        <button class="tiny-button" data-action="add-cart" data-id="${product.id}">Add to bag</button>
      </div>
    </div>
  </article>`;
}
function filteredProducts() {
  let products = state.products.filter((product) => state.activeCategory === "All" || product.category === state.activeCategory);
  if (state.search) products = products.filter((product) => `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(state.search.toLowerCase()));
  if (state.sort === "price-low") products.sort((a, b) => a.price - b.price);
  if (state.sort === "price-high") products.sort((a, b) => b.price - a.price);
  if (state.sort === "new") products.sort((a, b) => Number(b.badge === "New in") - Number(a.badge === "New in"));
  return products;
}
function renderHome() {
  const featured = state.products.slice(0, 4);
  app.innerHTML = `<div class="page">
    <section class="hero">
      <div class="hero-copy">
        <p class="eyebrow">Nigeria's phones & gadgets marketplace</p>
        <h1 class="hero-title">Tech that keeps you <em>moving.</em></h1>
        <p>Shop trusted phones, power, audio, wearables, protection, and storage in one place.</p>
        <div class="hero-actions"><a class="button button-dark" href="#/shop">Shop the inventory <span>→</span></a><a class="button button-ghost" href="#/story">Why ManteeTech</a></div>
      </div>
      <div class="hero-visual">
        <img src="https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=1600&q=85" alt="A modern smartphone and tech accessories on a desk" />
        <div class="hero-note"><p class="eyebrow">ManteeTech pick</p><strong>Reliable tech for work, play, and everything between.</strong></div>
      </div>
    </section>
    <div class="marquee"><div class="marquee-track">${["Phones", "Fast charging", "Clear sound", "Smart living", "Phones", "Fast charging", "Clear sound", "Smart living"].map((item) => `<span>${item}</span>`).join("")}</div></div>
    <section class="section">
      <div class="section-heading"><div><p class="eyebrow">Featured inventory</p><h2>Better tech,<br />well chosen.</h2></div><p>Start with a focused selection of devices and accessories that earn their place in your pocket, bag, desk, and home.</p></div>
      <div class="product-grid">${featured.map(productCard).join("")}</div>
    </section>
    <section class="feature-band">
      <div><p class="eyebrow">Why ManteeTech</p><h2>More signal,<br />less scrolling.</h2></div>
      <div><p>We make it easier to find the right device or accessory without wading through endless listings. Clear categories, useful specs, and dependable payment and delivery flows.</p>
        <div class="value-list"><div class="value-item"><span>01 / Useful</span><span>For work and everyday life</span></div><div class="value-item"><span>02 / Trusted</span><span>Brands people know</span></div><div class="value-item"><span>03 / Ready</span><span>Power when you need it</span></div></div>
      </div>
    </section>
  </div>`;
}
function renderShop() {
  const categories = ["All", ...new Set(state.products.map((product) => product.category))];
  app.innerHTML = `<div class="page">
    <section class="section"><div class="section-heading"><div><p class="eyebrow">The collection</p><h1>Shop all.</h1></div><p>${filteredProducts().length} objects, chosen with intention.</p></div>
      <div class="shop-layout">
        <aside class="shop-filters"><div class="filter-group"><p class="filter-title">Category</p>${categories.map((category) => `<label class="filter-option"><input type="radio" name="category" value="${category}" ${state.activeCategory === category ? "checked" : ""} /> ${category}</label>`).join("")}</div><div class="filter-group"><p class="filter-title">Collection</p><label class="filter-option"><input type="checkbox" data-new-only /> New in</label></div></aside>
        <div class="shop-main">
          <div class="search-bar"><span>⌕</span><input data-search type="search" placeholder="Search objects..." value="${esc(state.search)}" /></div>
          <div class="filter-bar"><span class="muted">${filteredProducts().length} results</span><select data-sort aria-label="Sort products"><option value="featured" ${state.sort === "featured" ? "selected" : ""}>Sort: Featured</option><option value="new" ${state.sort === "new" ? "selected" : ""}>Sort: Newest</option><option value="price-low" ${state.sort === "price-low" ? "selected" : ""}>Price: Low to high</option><option value="price-high" ${state.sort === "price-high" ? "selected" : ""}>Price: High to low</option></select></div>
          <div class="product-grid">${filteredProducts().length ? filteredProducts().map(productCard).join("") : `<div class="empty-state">No objects match that search yet.<br /><button class="text-button" data-action="clear-filters">Clear filters</button></div>`}</div>
        </div>
      </div>
    </section>
  </div>`;
}
function renderStory() {
  app.innerHTML = `<div class="page story-page"><section class="story-intro"><p class="eyebrow">About ManteeTech</p><h1>Find the tech that fits your life.</h1></section><section class="story-grid"><img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1400&q=85" alt="Modern desk setup with laptop and smartphone" /><div class="story-copy"><p class="eyebrow">A smarter way to shop</p><h2>Your devices should work harder, not shopping for them.</h2><p>ManteeTech is a focused marketplace for smartphones, tablets, power, audio, wearables, protection, and storage. We bring the essentials together so you can spend less time comparing tabs and more time getting things done.</p><p>From the phone in your hand to the charger in your bag, every category is built around the moments that depend on reliable tech.</p><a class="button button-dark" href="#/shop">Browse the inventory <span>→</span></a></div></section></div>`;
}
function renderCart() {
  const items = cartEntries();
  document.querySelector("[data-cart-items]").innerHTML = items.length ? items.map(({ product, quantity }) => `<div class="cart-item"><img src="${esc(product.image_url)}" alt="${esc(product.name)}" /><div><p class="cart-item-name">${esc(product.name)}</p><p class="cart-item-meta">${money(product.price)} · ${esc(product.category)}</p><div class="quantity-control"><button data-action="decrease" data-id="${product.id}">−</button><span>${quantity}</span><button data-action="increase" data-id="${product.id}">+</button></div></div><div class="cart-item-price">${money(product.price * quantity)}</div></div>`).join("") : `<div class="empty-state"><p>Your bag is waiting.</p><a class="button button-dark" href="#/shop" data-action="close-cart">Explore the collection</a></div>`;
  document.querySelector("[data-cart-subtotal]").textContent = money(cartTotal());
  document.querySelector("[data-action='checkout']").disabled = !items.length;
  updateHeader();
}
function addToCart(id) {
  state.cart[id] = (state.cart[id] || 0) + 1;
  saveLocal(); renderCart(); showToast("Added to your bag.");
}
function changeQuantity(id, amount) {
  state.cart[id] = (state.cart[id] || 0) + amount;
  if (state.cart[id] <= 0) delete state.cart[id];
  saveLocal(); renderCart();
}
function renderAccount() {
  const isAdmin = state.profile?.role === "admin";
  const orders = JSON.parse(localStorage.getItem("manteetech-orders") || "[]");
  const accountName = state.profile?.full_name || state.session?.user?.email?.split("@")[0] || "Guest";
  app.innerHTML = `<div class="page account-page"><div class="section-heading"><div><p class="eyebrow">Personal space</p><h1>Hello, ${esc(accountName)}.</h1></div>${isAdmin ? `<button class="button button-light" data-action="admin">Open admin</button>` : ""}</div><div class="account-layout"><nav class="account-nav"><button class="${state.accountTab === "overview" ? "active" : ""}" data-account-tab="overview">Overview</button><button class="${state.accountTab === "orders" ? "active" : ""}" data-account-tab="orders">Orders</button><button class="${state.accountTab === "saved" ? "active" : ""}" data-account-tab="saved">Saved items</button><button data-action="signout">Sign out</button></nav><div>${state.accountTab === "orders" ? renderOrders(orders) : state.accountTab === "saved" ? renderSaved() : renderOverview(orders)}</div></div></div>`;
}
function renderOverview(orders) {
  return `<div class="stat-grid"><div class="stat-card"><strong>${orders.length}</strong><span>Orders placed</span></div><div class="stat-card"><strong>${state.wishlist.length}</strong><span>Saved items</span></div><div class="stat-card"><strong>∞</strong><span>Good taste</span></div></div><div class="panel"><p class="eyebrow">Your next good thing</p><h3>There is no rush.</h3><p class="muted">Browse slowly, save what catches your eye, and come back when something feels right.</p><a class="button button-dark" href="#/shop">Continue browsing</a></div>`;
}
function renderOrders(orders) {
  return `<div class="panel"><h3>Your orders</h3>${orders.length ? `<table class="data-table"><thead><tr><th>Order</th><th>Date</th><th>Total</th><th>Status</th></tr></thead><tbody>${orders.map((order) => `<tr><td>#${esc(order.id.slice(-6).toUpperCase())}</td><td>${esc(order.date)}</td><td>${money(order.total)}</td><td><span class="status status-paid">${esc(order.status)}</span></td></tr>`).join("")}</tbody></table>` : `<div class="empty-state">Your first order will appear here.</div>`}</div>`;
}
function renderSaved() {
  const saved = state.products.filter((product) => state.wishlist.includes(product.id));
  return `<div class="panel"><h3>Saved items</h3>${saved.length ? `<div class="product-grid">${saved.map(productCard).join("")}</div>` : `<div class="empty-state">Save the pieces you want to remember.</div>`}</div>`;
}
function renderAdmin() {
  const orders = JSON.parse(localStorage.getItem("manteetech-orders") || "[]");
  const revenue = orders.reduce((sum, order) => sum + order.total, 0);
  app.innerHTML = `<div class="page admin-page"><div class="admin-header"><div><p class="eyebrow">Operations</p><h1>Store overview.</h1></div><span class="demo-badge">Demo admin mode</span></div><div class="stat-grid"><div class="stat-card"><strong>${money(revenue)}</strong><span>Gross sales</span></div><div class="stat-card"><strong>${orders.length}</strong><span>Orders</span></div><div class="stat-card"><strong>${state.products.length}</strong><span>Active products</span></div></div><div class="panel"><div class="section-heading"><div><p class="eyebrow">Catalog</p><h2>Products</h2></div><button class="button button-dark" data-action="admin-add">Add product</button></div><table class="data-table"><thead><tr><th>Product</th><th>Category</th><th>Stock</th><th>Price</th><th>Status</th></tr></thead><tbody>${state.products.map((product) => `<tr><td>${esc(product.name)}</td><td>${esc(product.category)}</td><td>${product.stock}</td><td>${money(product.price)}</td><td><span class="status status-active">Active</span></td></tr>`).join("")}</tbody></table></div></div>`;
}
function adminProductModal() {
  openModal(`<p class="eyebrow">Catalog management</p><h2>Add a product.</h2><form data-admin-form><div class="field"><label for="admin-name">Product name</label><input id="admin-name" name="name" required placeholder="e.g. Stoneware Bowl" /></div><div class="field-grid"><div class="field"><label for="admin-category">Category</label><input id="admin-category" name="category" required placeholder="Home" /></div><div class="field"><label for="admin-price">Price (NGN)</label><input id="admin-price" name="price" required type="number" min="0" step="100" placeholder="18000" /></div></div><div class="field-grid"><div class="field"><label for="admin-stock">Stock</label><input id="admin-stock" name="stock" required type="number" min="0" step="1" placeholder="10" /></div><div class="field"><label for="admin-image">Image URL</label><input id="admin-image" name="image_url" type="url" placeholder="https://..." /></div></div><div class="field"><label for="admin-description">Description</label><textarea id="admin-description" name="description" rows="3" placeholder="What makes this object worth keeping?"></textarea></div><button class="button button-dark button-full">Publish product <span>→</span></button></form>`);
}
async function createProduct(form) {
  const data = Object.fromEntries(new FormData(form));
  const product = {
    name: data.name,
    slug: data.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""),
    category: data.category,
    price: Number(data.price),
    compare_at: null,
    image_url: data.image_url || DEMO_PRODUCTS[0].image_url,
    colors: [],
    stock: Number(data.stock),
    badge: "New in",
    description: data.description || "A new ManteeTech product, selected for everyday use.",
    is_active: true
  };
  if (supabase) {
    const { data: inserted, error } = await supabase.from("products").insert(product).select().single();
    if (error) return showToast(error.message);
    state.products.unshift(inserted);
  } else {
    state.products.unshift({ ...product, id: crypto.randomUUID() });
  }
  closeModal(); renderAdmin(); showToast("Product published.");
}
function authModal() {
  openModal(`<p class="eyebrow">Welcome to ManteeTech</p><h2>${state.authMode === "signin" ? "Come on in." : "Make an account."}</h2><div class="auth-tabs"><button class="${state.authMode === "signin" ? "active" : ""}" data-auth-mode="signin">Sign in</button><button class="${state.authMode === "signup" ? "active" : ""}" data-auth-mode="signup">Create account</button></div><form data-auth-form><div class="field"><label for="auth-email">Email address</label><input id="auth-email" type="email" name="email" required placeholder="you@example.com" /></div><div class="field"><label for="auth-password">Password</label><input id="auth-password" type="password" name="password" required minlength="6" placeholder="At least 6 characters" /></div>${state.authMode === "signup" ? `<div class="field"><label for="auth-name">Your name</label><input id="auth-name" name="name" required placeholder="First name" /></div>` : ""}<button class="button button-dark button-full">${state.authMode === "signin" ? "Sign in" : "Create account"} <span>→</span></button></form><p class="fine-print">${supabase ? "Connected to Supabase authentication." : "Demo mode is active. Use any email and password to explore."}</p>`);
}
function checkoutModal() {
  state.checkoutStep = 1;
  renderCheckout();
}
function renderCheckout() {
  const step = state.checkoutStep;
  const order = cartTotal();
  openModal(`<div class="checkout-steps"><span class="checkout-step ${step === 1 ? "active" : ""}">1. Details</span><span class="checkout-step ${step === 2 ? "active" : ""}">2. Payment</span><span class="checkout-step ${step === 3 ? "active" : ""}">3. Done</span></div>${step === 1 ? `<p class="eyebrow">Almost yours</p><h2>Delivery details.</h2><form data-checkout-form><div class="field"><label for="checkout-name">Full name</label><input id="checkout-name" name="name" required value="${esc(state.profile?.full_name || "")}" placeholder="Your full name" /></div><div class="field"><label for="checkout-email">Email</label><input id="checkout-email" name="email" required type="email" value="${esc(state.session?.user?.email || "")}" placeholder="you@example.com" /></div><div class="field"><label for="checkout-address">Delivery address</label><textarea id="checkout-address" name="address" required rows="3" placeholder="Street, city, state">${esc(state.checkoutAddress || "")}</textarea></div><button class="button button-dark button-full">Continue to payment <span>→</span></button></form>` : step === 2 ? `<p class="eyebrow">Secure checkout</p><h2>Make it yours.</h2><div class="notice">${CONFIG.paystackPublicKey ? "You will be redirected to Paystack's secure payment window." : "Demo payment mode is active. Add a Paystack public key to accept live payments."}</div><div class="checkout-total"><div class="summary-line"><span>Order total</span><strong>${money(order)}</strong></div></div><button class="button button-dark button-full" data-action="pay">Pay ${money(order)} <span>→</span></button><button class="text-button button-full" data-action="back-checkout">← Back to details</button>` : `<div class="empty-state"><span class="demo-badge">Order confirmed</span><h2>Thank you.</h2><p>Your order <strong>#${esc(state.lastOrder?.id.slice(-6).toUpperCase())}</strong> is on its way to becoming real.</p><p class="muted">A confirmation would be sent to ${esc(state.lastOrder?.email)} in production.</p><a class="button button-dark" href="#/shop" data-action="close-modal">Keep browsing <span>→</span></a></div>`}`);
}
async function initializeSupabase() {
  if (!supabase) return;
  const { data: products } = await supabase.from("products").select("*").eq("is_active", true).order("created_at", { ascending: false });
  if (products?.length) { state.products = products; renderRoute(); }
  const { data: { session } } = await supabase.auth.getSession();
  if (session) await applySession(session);
  supabase.auth.onAuthStateChange((_event, session) => applySession(session));
}
async function applySession(session) {
  state.session = session;
  if (session && supabase) {
    const { data } = await supabase.from("profiles").select("*").eq("id", session.user.id).maybeSingle();
    state.profile = data;
  } else state.profile = null;
  if (location.hash === "#/account") renderAccount();
}
async function submitAuth(form) {
  const data = Object.fromEntries(new FormData(form));
  if (supabase) {
    const response = state.authMode === "signin"
      ? await supabase.auth.signInWithPassword({ email: data.email, password: data.password })
      : await supabase.auth.signUp({ email: data.email, password: data.password, options: { data: { full_name: data.name } } });
    if (response.error) return showToast(response.error.message);
    closeModal(); showToast(state.authMode === "signin" ? "Welcome back." : "Check your email to confirm your account.");
  } else {
    state.session = { user: { email: data.email } }; state.profile = { full_name: data.name || data.email.split("@")[0], role: data.email.includes("admin") ? "admin" : "customer" };
    closeModal(); showToast("Demo account ready."); renderAccount();
  }
}
async function createOrder() {
  const order = { id: crypto.randomUUID(), date: formatDate(), email: state.checkoutEmail || state.session?.user?.email || "demo@example.com", total: cartTotal(), status: "Paid", items: cartEntries().map(({ product, quantity }) => ({ product_id: product.id, quantity, price: product.price })) };
  if (supabase && state.session) {
    const { data, error } = await supabase.rpc("create_order", { p_items: order.items, p_email: order.email, p_shipping_address: state.checkoutAddress || "" });
    if (error) return showToast(error.message);
    order.id = data?.id || order.id;
  }
  const orders = JSON.parse(localStorage.getItem("manteetech-orders") || "[]");
  localStorage.setItem("manteetech-orders", JSON.stringify([order, ...orders]));
  state.lastOrder = order; state.cart = {}; saveLocal(); state.checkoutStep = 3; renderCheckout(); renderCart();
}
function pay() {
  if (CONFIG.paystackPublicKey && window.PaystackPop) {
    const handler = window.PaystackPop.setup({ key: CONFIG.paystackPublicKey, email: state.checkoutEmail, amount: cartTotal() * 100, currency: "NGN", ref: `manteetech-${Date.now()}`, callback: createOrder, onClose: () => showToast("Payment window closed.") });
    handler.openIframe();
  } else { showToast("Demo payment accepted."); createOrder(); }
}
function renderRoute() {
  const route = location.hash.replace("#/", "") || "";
  if (route === "shop" || route === "new") { if (route === "new") { state.sort = "new"; state.search = ""; } renderShop(); }
  else if (route === "story") renderStory();
  else if (route === "account") { if (!state.session && !state.profile) { authModal(); return; } renderAccount(); }
  else if (route === "admin") { if (state.profile?.role === "admin") renderAdmin(); else { showToast("Admin access is restricted."); location.hash = "#/account"; } }
  else renderHome();
  window.scrollTo({ top: 0, behavior: "instant" });
}
document.addEventListener("click", async (event) => {
  const target = event.target.closest("[data-action], [data-account-tab], [data-auth-mode]");
  if (!target) return;
  const action = target.dataset.action;
  if (action === "cart") openCart();
  if (action === "close-cart") closeCart();
  if (action === "close-modal") closeModal();
  if (action === "add-cart") addToCart(target.dataset.id);
  if (action === "quick-view") { const product = state.products.find((item) => item.id === target.dataset.id); openModal(`<div class="modal-product"><img src="${esc(product.image_url)}" alt="${esc(product.name)}" /><div class="modal-copy"><p class="eyebrow">${esc(product.category)}</p><h2>${esc(product.name)}</h2><p>${esc(product.description)}</p><strong>${money(product.price)}</strong><br /><button class="button button-dark" style="margin-top:1.5rem" data-action="modal-add-cart" data-id="${product.id}">Add to bag <span>→</span></button></div></div>`); }
  if (action === "modal-add-cart") { addToCart(target.dataset.id); closeModal(); }
  if (action === "wishlist") { state.wishlist = state.wishlist.includes(target.dataset.id) ? state.wishlist.filter((id) => id !== target.dataset.id) : [...state.wishlist, target.dataset.id]; saveLocal(); renderRoute(); showToast(state.wishlist.includes(target.dataset.id) ? "Saved for later." : "Removed from saved items."); }
  if (action === "increase") changeQuantity(target.dataset.id, 1);
  if (action === "decrease") changeQuantity(target.dataset.id, -1);
  if (action === "checkout") { closeCart(); if (!state.session && !state.profile) { showToast("You can checkout as a guest."); } checkoutModal(); }
  if (action === "open-search") { if (!location.hash.includes("shop")) location.hash = "#/shop"; setTimeout(() => document.querySelector("[data-search]")?.focus(), 0); }
  if (action === "account") location.hash = "#/account";
  if (action === "clear-filters") { state.search = ""; state.activeCategory = "All"; renderShop(); }
  if (action === "signout") { if (supabase) await supabase.auth.signOut(); state.session = null; state.profile = null; location.hash = "#/"; showToast("Signed out."); }
  if (action === "admin") location.hash = "#/admin";
  if (action === "admin-add") adminProductModal();
  if (action === "back-checkout") { state.checkoutStep = 1; renderCheckout(); }
  if (action === "pay") pay();
  if (target.dataset.accountTab) { state.accountTab = target.dataset.accountTab; renderAccount(); }
  if (target.dataset.authMode) { state.authMode = target.dataset.authMode; authModal(); }
});
document.addEventListener("submit", async (event) => {
  if (event.target.matches("[data-auth-form]")) { event.preventDefault(); await submitAuth(event.target); }
  if (event.target.matches("[data-checkout-form]")) { event.preventDefault(); const data = Object.fromEntries(new FormData(event.target)); state.checkoutEmail = data.email; state.checkoutAddress = data.address; state.checkoutStep = 2; renderCheckout(); }
  if (event.target.matches("[data-admin-form]")) { event.preventDefault(); await createProduct(event.target); }
});
document.addEventListener("input", (event) => {
  if (event.target.matches("[data-search]")) { state.search = event.target.value; renderShop(); setTimeout(() => { const input = document.querySelector("[data-search]"); input?.focus(); input?.setSelectionRange(state.search.length, state.search.length); }, 0); }
});
document.addEventListener("change", (event) => {
  if (event.target.name === "category") { state.activeCategory = event.target.value; renderShop(); }
  if (event.target.matches("[data-sort]")) { state.sort = event.target.value; renderShop(); }
  if (event.target.matches("[data-new-only]")) { state.sort = event.target.checked ? "new" : "featured"; renderShop(); }
});
modalLayer.addEventListener("click", (event) => { if (event.target === modalLayer) closeModal(); });
drawerBackdrop.addEventListener("click", closeCart);
window.addEventListener("hashchange", renderRoute);
window.addEventListener("keydown", (event) => { if (event.key === "Escape") { closeModal(); closeCart(); } });
document.querySelector("[data-action='account']").addEventListener("click", () => { if (!state.session && !state.profile) authModal(); });
renderRoute();
renderCart();
initializeSupabase();