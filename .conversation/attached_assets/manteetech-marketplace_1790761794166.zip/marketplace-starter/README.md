# ManteeTech Marketplace

A production-minded vanilla HTML/CSS/JS marketplace starter for ManteeTech's phones and gadgets inventory, with a Supabase schema, Paystack-ready checkout, customer account area, admin view, responsive UI, demo data, search, filters, saved items, and local persistence.

## What is included

- Single-page storefront with hash routing: Home, Shop, New in, About ManteeTech, Account, Admin
- Demo inventory covering smartphones/tablets, power and energy, audio, wearables, protection, and storage
- Responsive storefront designed for desktop and small screens
- Product cards, quick view, search, category filters, sort, wishlist, cart drawer
- Guest checkout demo and Paystack Inline JS integration point
- Supabase Auth, product catalog hydration, profile roles, order RPC, RLS policies
- Customer order history and saved items
- Admin dashboard surface with inventory/revenue/order stats
- Admin product creation flow (RLS-protected against the Supabase catalog)
- One authoritative visual token file: `design-tokens.css`
- No secrets in the browser; Paystack secret-key work belongs in a server/Edge Function

## Run locally

Because the app is ES-module based, serve the folder through a local web server:

```bash
cd marketplace-starter
python3 -m http.server 4173
```

Then open `http://localhost:4173`.

The app works in demo mode without any setup. Demo accounts accept any email and a six-character password. Use an email containing `admin` to preview the admin dashboard.

## Supabase setup

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the SQL Editor.
3. Run `supabase/seed.sql`.
4. Copy your project URL and anon key into `index.html` `window.APP_CONFIG`, or inject them through your host at build/deploy time.
5. Create a real admin by updating a profile row:

```sql
update public.profiles set role = 'admin' where id = 'YOUR_AUTH_USER_UUID';
```

The client only uses the public anon key. RLS and the `create_order` RPC enforce access. For live payment fulfillment, verify Paystack transactions server-side before marking an order paid. A deployable starter is included at `supabase/functions/paystack-verify/index.ts`; set `PAYSTACK_SECRET_KEY` and `SUPABASE_SERVICE_ROLE_KEY` as Supabase project secrets. Do not put either secret in this frontend.

## Paystack

Set `paystackPublicKey` in `window.APP_CONFIG`. The checkout will use Paystack Inline JS and pass the callback into the order creation flow. For production, replace the client callback with a server/Edge Function that:

1. Initializes a transaction with the Paystack secret key.
2. Verifies the reference from the webhook or callback. The included `paystack-verify` function shows this boundary.
3. Creates/updates the order idempotently.
4. Decrements inventory only after verified payment.

## Agile delivery plan

### Sprint 1 — Foundation

- [x] Tokenized visual system and responsive shell
- [x] Demo catalog and storefront routes
- [x] Search, category filters, sort, wishlist, cart

### Sprint 2 — Accounts and data

- [x] Supabase schema, RLS, profile trigger
- [x] Email/password auth surface
- [x] Customer orders and saved items
- [ ] Email confirmation and password reset screens

### Sprint 3 — Commerce

- [x] Checkout UX and Paystack integration point
- [x] Order creation RPC
- [ ] Server-side Paystack verification/webhooks
- [ ] Delivery-rate provider and receipt emails

### Sprint 4 — Operations

- [x] Admin dashboard surface
- [x] Admin product create form
- [ ] Admin product edit/archive forms
- [ ] Fulfillment workflow and audit log
- [ ] Observability, rate limiting, automated E2E tests

## Deployment

Deploy the folder to any static host that supports SPA fallback, or move the files into a Replit web project for a durable hosted app. Configure environment values through the host's secret/environment manager and never commit production credentials.